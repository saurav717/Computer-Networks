Readme 

compile and run the code with the following commands

 to compile : g++ Assign1Src-ES16BTECH11007.cpp -lrt
 to execute : ./a.out <command>

refer to the documentation to understand what is going on in the code
